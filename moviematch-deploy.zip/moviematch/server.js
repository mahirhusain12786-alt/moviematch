const express = require('express');
const { WebSocketServer, WebSocket } = require('ws');
const http = require('http');
const path = require('path');
const crypto = require('crypto');

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// In-memory rooms store
// room: { code, users: [{ws, name, likes:[]}], phase, currentMovieIndex }
const rooms = new Map();

// Hardcoded popular movies with streaming links (India-focused)
const MOVIES = [
  { id:1, title:"Stree 2", year:2024, genre:"Horror Comedy", language:"Hindi", emoji:"👻", rating:7.6, description:"Chanderi mein phir aayi Stree — ab isse rokna aur mushkil hai.", platform:"Amazon Prime Video", platformColor:"#00A8E0", watchUrl:"https://www.primevideo.com/search/?phrase=Stree+2", trailerUrl:"https://www.youtube.com/results?search_query=Stree+2+trailer" },
  { id:2, title:"Pushpa 2: The Rule", year:2024, genre:"Action", language:"Hindi", emoji:"🌿", rating:7.4, description:"Pushpa Raj ab rule karta hai — thhela nahi, fire hai ekdum.", platform:"Amazon Prime Video", platformColor:"#00A8E0", watchUrl:"https://www.primevideo.com/search/?phrase=Pushpa+2", trailerUrl:"https://www.youtube.com/results?search_query=Pushpa+2+trailer" },
  { id:3, title:"12th Fail", year:2023, genre:"Drama", language:"Hindi", emoji:"📚", rating:9.0, description:"IPS banne ki sachchi kahani — haar maanna asaan hai, jeetna nahi.", platform:"Disney+ Hotstar", platformColor:"#1A6BE0", watchUrl:"https://www.hotstar.com/in/search?q=12th+fail", trailerUrl:"https://www.youtube.com/results?search_query=12th+fail+trailer" },
  { id:4, title:"Animal", year:2023, genre:"Action Drama", language:"Hindi", emoji:"🐯", rating:6.5, description:"Ek beta, ek baap — aur beech mein ek darkest obsession.", platform:"Netflix", platformColor:"#E50914", watchUrl:"https://www.netflix.com/search?q=Animal+2023", trailerUrl:"https://www.youtube.com/results?search_query=Animal+2023+trailer" },
  { id:5, title:"Jawan", year:2023, genre:"Action Thriller", language:"Hindi", emoji:"🧑‍✈️", rating:7.0, description:"Ek banda poori system ke khilaf — SRK is back with a bang.", platform:"Netflix", platformColor:"#E50914", watchUrl:"https://www.netflix.com/search?q=Jawan+2023", trailerUrl:"https://www.youtube.com/results?search_query=Jawan+2023+trailer" },
  { id:6, title:"Oppenheimer", year:2023, genre:"Historical Drama", language:"English", emoji:"💣", rating:8.9, description:"Wo scientist jisne duniya ka sabse khatarnak weapon banaya — aur regret kiya.", platform:"JioCinema", platformColor:"#FF6B00", watchUrl:"https://www.jiocinema.com/search?search_query=Oppenheimer", trailerUrl:"https://www.youtube.com/results?search_query=Oppenheimer+trailer" },
  { id:7, title:"RRR", year:2022, genre:"Action Epic", language:"Hindi", emoji:"🔥", rating:7.9, description:"Do azaad sipahi, ek dhamakedar friendship — S.S. Rajamouli ka masterpiece.", platform:"Netflix", platformColor:"#E50914", watchUrl:"https://www.netflix.com/search?q=RRR", trailerUrl:"https://www.youtube.com/results?search_query=RRR+movie+trailer" },
  { id:8, title:"KGF Chapter 2", year:2022, genre:"Action", language:"Hindi", emoji:"⚒️", rating:8.3, description:"Rocky bhai ka raj — sone ki khanon se leke puri duniya tak.", platform:"Amazon Prime Video", platformColor:"#00A8E0", watchUrl:"https://www.primevideo.com/search/?phrase=KGF+Chapter+2", trailerUrl:"https://www.youtube.com/results?search_query=KGF+Chapter+2+trailer" },
  { id:9, title:"Drishyam 2", year:2022, genre:"Thriller", language:"Hindi", emoji:"🕵️", rating:8.0, description:"Vijay Salgaonkar ka ek aur kadam — truth ko bury karna art hai.", platform:"Amazon Prime Video", platformColor:"#00A8E0", watchUrl:"https://www.primevideo.com/search/?phrase=Drishyam+2", trailerUrl:"https://www.youtube.com/results?search_query=Drishyam+2+trailer" },
  { id:10, title:"Kalki 2898 AD", year:2024, genre:"Sci-Fi Action", language:"Hindi", emoji:"⚡", rating:6.8, description:"Future India mein ek avatar — mythology meets sci-fi spectacle.", platform:"Netflix", platformColor:"#E50914", watchUrl:"https://www.netflix.com/search?q=Kalki+2898", trailerUrl:"https://www.youtube.com/results?search_query=Kalki+2898+AD+trailer" },
  { id:11, title:"Fighter", year:2024, genre:"Action", language:"Hindi", emoji:"✈️", rating:6.2, description:"Indian Air Force ki kahani — sky is not the limit.", platform:"Netflix", platformColor:"#E50914", watchUrl:"https://www.netflix.com/search?q=Fighter+2024", trailerUrl:"https://www.youtube.com/results?search_query=Fighter+2024+trailer" },
  { id:12, title:"Crew", year:2024, genre:"Comedy Thriller", language:"Hindi", emoji:"💼", rating:6.5, description:"Teen air hostesses, ek bada jugaad — girls just wanna have gold.", platform:"Netflix", platformColor:"#E50914", watchUrl:"https://www.netflix.com/search?q=Crew+2024", trailerUrl:"https://www.youtube.com/results?search_query=Crew+2024+trailer" },
  { id:13, title:"Merry Christmas", year:2024, genre:"Thriller", language:"Hindi", emoji:"🎄", rating:7.1, description:"Ek raat, ek stranger, ek deadly secret — Sriram Raghavan magic.", platform:"Amazon Prime Video", platformColor:"#00A8E0", watchUrl:"https://www.primevideo.com/search/?phrase=Merry+Christmas+2024", trailerUrl:"https://www.youtube.com/results?search_query=Merry+Christmas+2024+hindi+trailer" },
  { id:14, title:"Amar Singh Chamkila", year:2024, genre:"Biographical", language:"Hindi/Punjabi", emoji:"🎸", rating:7.9, description:"Punjab ka rockstar — jee bhar ke jeena, marna bhi usne khud chuna.", platform:"Netflix", platformColor:"#E50914", watchUrl:"https://www.netflix.com/search?q=Amar+Singh+Chamkila", trailerUrl:"https://www.youtube.com/results?search_query=Amar+Singh+Chamkila+trailer" },
  { id:15, title:"Maharaj", year:2024, genre:"Historical Drama", language:"Hindi", emoji:"👑", rating:7.2, description:"1862 ka ek journalist jo ek dhongi baba ke khilaf lada — and won.", platform:"Netflix", platformColor:"#E50914", watchUrl:"https://www.netflix.com/search?q=Maharaj+2024", trailerUrl:"https://www.youtube.com/results?search_query=Maharaj+2024+netflix+trailer" }
];

function generateRoomCode() {
  return crypto.randomBytes(3).toString('hex').toUpperCase().substring(0, 4);
}

function broadcast(room, data, excludeWs = null) {
  room.users.forEach(u => {
    if (u.ws !== excludeWs && u.ws.readyState === WebSocket.OPEN) {
      u.ws.send(JSON.stringify(data));
    }
  });
}

function broadcastAll(room, data) {
  room.users.forEach(u => {
    if (u.ws.readyState === WebSocket.OPEN) {
      u.ws.send(JSON.stringify(data));
    }
  });
}

function checkMatches(room) {
  if (room.users.length < 2) return;
  const [u1, u2] = room.users;
  const matches = u1.likes.filter(id => u2.likes.includes(id));
  const newMatches = matches.filter(id => !room.announcedMatches.includes(id));
  newMatches.forEach(id => {
    const movie = MOVIES.find(m => m.id === id);
    if (movie) {
      room.announcedMatches.push(id);
      broadcastAll(room, { type: 'match', movie, matchedBy: [u1.name, u2.name] });
    }
  });
}

wss.on('connection', (ws) => {
  let userRoom = null;
  let userName = null;

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }

    if (msg.type === 'create_room') {
      const code = generateRoomCode();
      const room = { code, users: [], announcedMatches: [], createdAt: Date.now() };
      rooms.set(code, room);
      userName = msg.name || 'User1';
      const user = { ws, name: userName, likes: [] };
      room.users.push(user);
      userRoom = room;
      ws.send(JSON.stringify({ type: 'room_created', code, movies: MOVIES, name: userName }));
    }

    else if (msg.type === 'join_room') {
      const code = msg.code.toUpperCase();
      const room = rooms.get(code);
      if (!room) { ws.send(JSON.stringify({ type: 'error', message: 'Room nahi mila! Code check karo.' })); return; }
      if (room.users.length >= 2) { ws.send(JSON.stringify({ type: 'error', message: 'Room full hai! Naya room banao.' })); return; }
      userName = msg.name || 'User2';
      const user = { ws, name: userName, likes: [] };
      room.users.push(user);
      userRoom = room;
      ws.send(JSON.stringify({ type: 'room_joined', code, movies: MOVIES, name: userName, partnerName: room.users[0].name }));
      broadcast(room, { type: 'partner_joined', partnerName: userName }, ws);
    }

    else if (msg.type === 'swipe') {
      if (!userRoom) return;
      const user = userRoom.users.find(u => u.ws === ws);
      if (!user) return;
      if (msg.liked) {
        if (!user.likes.includes(msg.movieId)) user.likes.push(msg.movieId);
        checkMatches(userRoom);
      }
      broadcast(userRoom, { type: 'partner_swiped', movieId: msg.movieId, liked: msg.liked }, ws);
    }
  });

  ws.on('close', () => {
    if (userRoom) {
      broadcast(userRoom, { type: 'partner_left', name: userName });
      userRoom.users = userRoom.users.filter(u => u.ws !== ws);
      if (userRoom.users.length === 0) {
        rooms.delete(userRoom.code);
      }
    }
  });
});

// Cleanup old rooms every 10 minutes
setInterval(() => {
  const now = Date.now();
  rooms.forEach((room, code) => {
    if (now - room.createdAt > 3600000) rooms.delete(code);
  });
}, 600000);

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`MovieMatch running on port ${PORT}`));
