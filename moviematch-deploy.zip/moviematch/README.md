# 🎬 MovieMatch — Movie Tinder for Friends

Dono friends ek saath movies swipe karte hain. Match hone par movie ka direct link milta hai!

## Features
- Real-time multiplayer (WebSocket)
- Room code system — koi bhi join kar sakta hai
- 15 latest Bollywood + Hollywood movies
- Netflix, Prime, Hotstar, JioCinema links
- YouTube trailer
- Mobile + Desktop dono pe works
- Keyboard shortcuts: ← Nope | → Like

---

## 🚀 Deploy on Render.com (FREE — 5 minutes)

### Step 1: GitHub pe upload karo
1. github.com pe jaao → New Repository → "moviematch"
2. Saare files upload karo (package.json, server.js, render.yaml, public/index.html)

### Step 2: Render pe deploy karo
1. render.com pe jaao → Sign up (free)
2. "New Web Service" → Connect GitHub repo
3. Settings automatically detect ho jaayenge (render.yaml se)
4. "Deploy" dabao — 2-3 minute mein live ho jaayega!

### Step 3: Use karo!
- Render tumhe ek URL dega jaise: `https://moviematch-xxxx.onrender.com`
- Ye URL dono logon ko share karo
- Enjoy! 🍿

---

## 💻 Local Testing (apne computer pe)

```bash
npm install
node server.js
```
Browser mein jaao: http://localhost:3000

Ek tab mein room banao, doosre tab mein join karo — test ho jaayega!

---

## 🎮 How to Play
1. Apna naam daalo
2. "Naya Room Banao" → Code copy karo
3. Dost ko code bhejo (WhatsApp/SMS)
4. Dost code daalkae join kare
5. Dono swipe karo — ♥ ya ✕
6. Match hone par notification aata hai
7. Seedha platform pe jaake movie dekho!

---

## Tech Stack
- Node.js + Express (server)
- WebSocket (ws library) — real-time sync
- Vanilla HTML/CSS/JS (frontend)
- No database needed!
